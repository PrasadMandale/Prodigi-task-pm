# "Simple Weather Application using HTML, CSS &amp; JavaScript"

## Overview of Weather App

It's a  Simple Weather Application made by using HTML, CSS &amp; JavaScript.

The app is created by [J. Siv Ram Shastri](https://www.linkedin.com/in/imsivram1999/) for helping out the beginners on how to make Simple Weather Application using HTML, CSS &amp; JavaScript

Live Demo:  https://prince-shivaram.github.io/Simple-Weather-App/

## Show some :heart: and :star: the repo if you like the design.

![WeatherApp](https://user-images.githubusercontent.com/42378118/99897986-fd02dc00-2cc3-11eb-9cac-f5b577bfef40.png)


# Project README

This project was given by [Prodigy Infotech](https://prodigyinfotech.dev/) as Task 3.

See [Demo](https://prodigy-internship-task-3.vercel.app/)

The title is "Tic-Tac-Toe" and it is a game made with React.js. It is offline two player game.

